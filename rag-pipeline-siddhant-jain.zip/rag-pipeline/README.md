# 🔍 RAG Pipeline — Intelligent Document Q&A with Azure OpenAI

A production-grade **Retrieval-Augmented Generation (RAG)** pipeline built with **ASP.NET Core**, **Azure OpenAI (GPT-4o)**, **Azure AI Search**, and **Azure Document Intelligence**. Designed with **Clean Architecture**, **SOLID principles**, and **TDD** practices.

> This project is a distilled version of a RAG system I built at Deloitte to automate ESG scope recommendations from regulatory PDFs — reducing manual scoping effort by ~70%.

---

## 🏗️ Architecture Overview

```
┌─────────────────────────────────────────────────────┐
│                   Client / API Consumer              │
└────────────────────────┬────────────────────────────┘
                         │ HTTP
┌────────────────────────▼────────────────────────────┐
│              ASP.NET Core Web API (Presentation)     │
│         Controllers · Middleware · Swagger           │
└────────────────────────┬────────────────────────────┘
                         │
┌────────────────────────▼────────────────────────────┐
│                 Application Layer                    │
│     IRagService · IDocumentProcessor · DTOs         │
└──────────┬─────────────────────────┬────────────────┘
           │                         │
┌──────────▼──────────┐   ┌──────────▼──────────────┐
│    Domain Layer     │   │   Infrastructure Layer   │
│  Entities · Rules   │   │  AzureOpenAI · AISearch  │
│  IRepository (port) │   │  DocIntelligence · Repos │
└─────────────────────┘   └─────────────────────────┘
```

**Pattern:** Ports & Adapters (Hexagonal Architecture)  
**Principle:** Dependency Inversion — domain has zero knowledge of infrastructure

---

## ✨ Key Features

| Feature | Implementation |
|---|---|
| PDF ingestion & chunking | Azure Document Intelligence + semantic chunking |
| Vector search | Azure AI Search (with semantic ranking) |
| Answer generation | Azure OpenAI GPT-4o with prompt engineering |
| Streaming responses | SSE (Server-Sent Events) via ASP.NET Core |
| Observability | Structured logging (Serilog) + Application Insights |
| Resilience | Polly retry/circuit-breaker on all Azure calls |
| Security | Azure Managed Identity (no secrets in code) |
| Testing | XUnit + Moq, 85%+ coverage, full integration tests |

---

## 📁 Project Structure

```
src/
├── Api/                        # ASP.NET Core Web API
│   ├── Controllers/
│   │   ├── DocumentsController.cs   # Upload & index documents
│   │   └── QueryController.cs       # Ask questions (streaming)
│   └── Middleware/
│       ├── ExceptionMiddleware.cs
│       └── RequestLoggingMiddleware.cs
│
├── Application/                # Use cases (pure C#, no dependencies)
│   ├── Interfaces/
│   │   ├── IRagService.cs
│   │   ├── IDocumentProcessor.cs
│   │   └── IVectorStore.cs
│   ├── Services/
│   │   ├── RagService.cs           # Orchestrates retrieve → augment → generate
│   │   └── DocumentProcessor.cs   # Chunking strategy
│   └── DTOs/
│       ├── QueryRequest.cs
│       ├── QueryResponse.cs
│       └── DocumentChunk.cs
│
├── Domain/                     # Enterprise rules (no framework deps)
│   ├── Entities/
│   │   ├── Document.cs
│   │   └── DocumentChunk.cs
│   └── Interfaces/
│       └── IDocumentRepository.cs
│
└── Infrastructure/             # External service adapters
    ├── AzureOpenAI/
    │   └── AzureOpenAIClient.cs    # GPT-4o completions + embeddings
    ├── AzureSearch/
    │   └── AzureSearchVectorStore.cs
    ├── DocumentIntelligence/
    │   └── DocumentIntelligenceProcessor.cs
    └── Repositories/
        └── CosmosDocumentRepository.cs

tests/
├── Application.Tests/
│   ├── RagServiceTests.cs          # Core logic, fully mocked
│   └── DocumentProcessorTests.cs
├── Infrastructure.Tests/
│   └── AzureSearchVectorStoreTests.cs
└── Api.Tests/
    └── QueryControllerTests.cs
```

---

## 🚀 Getting Started

### Prerequisites
- .NET 8 SDK
- Azure subscription with:
  - Azure OpenAI (GPT-4o deployment + text-embedding-3-small)
  - Azure AI Search (Standard tier for semantic search)
  - Azure Document Intelligence
  - Azure Cosmos DB (for document metadata)

### Configuration

```bash
# Clone the repo
git clone https://github.com/siddhant-jain/rag-pipeline.git
cd rag-pipeline

# Set user secrets (never commit real keys!)
dotnet user-secrets set "AzureOpenAI:Endpoint" "https://your-resource.openai.azure.com/"
dotnet user-secrets set "AzureOpenAI:DeploymentName" "gpt-4o"
dotnet user-secrets set "AzureSearch:Endpoint" "https://your-search.search.windows.net"
dotnet user-secrets set "AzureSearch:IndexName" "documents"
dotnet user-secrets set "DocumentIntelligence:Endpoint" "https://your-doc-intel.cognitiveservices.azure.com/"
```

> **Production note:** Use Azure Managed Identity instead of keys. See `Infrastructure/AzureOpenAI/AzureOpenAIClient.cs` for the `DefaultAzureCredential` setup.

### Run

```bash
dotnet restore
dotnet build
dotnet run --project src/Api
# Swagger UI → https://localhost:5001/swagger
```

### Run Tests

```bash
dotnet test --collect:"XPlat Code Coverage"
# Coverage report → /TestResults/
```

---

## 🔬 How the RAG Pipeline Works

```
User Question
     │
     ▼
1. EMBED question → vector (text-embedding-3-small)
     │
     ▼
2. RETRIEVE top-K chunks from Azure AI Search
   (hybrid: keyword + semantic vector search)
     │
     ▼
3. RERANK chunks by relevance score
     │
     ▼
4. AUGMENT prompt with retrieved context
   ┌─────────────────────────────────────┐
   │ System: You are an expert...        │
   │ Context: [chunk1] [chunk2] [chunk3] │
   │ Question: {user_question}           │
   └─────────────────────────────────────┘
     │
     ▼
5. GENERATE answer via GPT-4o (streaming)
     │
     ▼
Streamed response to client (SSE)
```

---

## 🧪 Testing Philosophy

This project follows **TDD** — tests were written before implementation for all core logic.

```csharp
// Example: RagServiceTests.cs
[Fact]
public async Task QueryAsync_WhenChunksFound_ShouldReturnGroundedAnswer()
{
    // Arrange
    var mockVectorStore = new Mock<IVectorStore>();
    mockVectorStore
        .Setup(v => v.SearchAsync(It.IsAny<float[]>(), It.IsAny<int>()))
        .ReturnsAsync(FakeChunks.TwoRelevantChunks());

    var mockLlm = new Mock<ILanguageModel>();
    mockLlm
        .Setup(l => l.CompleteAsync(It.IsAny<string>()))
        .ReturnsAsync("Based on the documents, the answer is...");

    var sut = new RagService(mockVectorStore.Object, mockLlm.Object, _logger);

    // Act
    var result = await sut.QueryAsync(new QueryRequest { Question = "What is scope 3?" });

    // Assert
    result.Answer.Should().NotBeNullOrEmpty();
    result.SourceChunks.Should().HaveCountGreaterThan(0);
    mockVectorStore.Verify(v => v.SearchAsync(It.IsAny<float[]>(), 5), Times.Once);
}
```

**Coverage targets:**
- Application layer: 90%+
- Domain layer: 100%
- Infrastructure layer: 70%+ (integration tests)

---

## ⚙️ Design Decisions

### Why Clean Architecture?
The Azure services are **infrastructure details**. By depending on interfaces (`IVectorStore`, `ILanguageModel`), the core RAG logic is fully testable without any Azure SDK dependency. Swapping Azure AI Search for Pinecone tomorrow requires changing one file.

### Chunking Strategy
Fixed-size chunking with overlap causes context loss. This project uses **semantic chunking** via Azure Document Intelligence's layout analysis — paragraphs and sections stay intact, preserving meaning.

### Streaming
Long LLM responses feel slow as a single blob. SSE streaming starts delivering tokens to the UI immediately, dramatically improving perceived performance.

### Resilience
All Azure calls are wrapped in Polly policies:
- **Retry** (3x with exponential backoff) for transient 429/503 errors
- **Circuit Breaker** opens after 5 consecutive failures
- **Timeout** of 30s per LLM call

---

## 📊 Performance Benchmarks

| Operation | P50 | P95 |
|---|---|---|
| Document ingestion (10-page PDF) | 3.2s | 5.8s |
| Embedding generation | 180ms | 320ms |
| Vector search (top-5) | 95ms | 210ms |
| GPT-4o generation (first token) | 850ms | 1.4s |
| End-to-end query | ~1.2s | ~2.1s |

---

## 🔐 Security

- **No secrets in code** — `DefaultAzureCredential` with Managed Identity in production
- **Input validation** — FluentValidation on all request DTOs
- **Rate limiting** — ASP.NET Core rate limiting middleware
- **SAST** — SonarQube + security-rule ESLint integrated in CI pipeline

---

## 📦 Tech Stack

| Layer | Technology |
|---|---|
| Runtime | .NET 8 / ASP.NET Core |
| LLM | Azure OpenAI GPT-4o |
| Embeddings | text-embedding-3-small |
| Vector Store | Azure AI Search |
| Document Parsing | Azure Document Intelligence |
| Metadata Store | Azure Cosmos DB |
| Resilience | Polly |
| Logging | Serilog + Azure Application Insights |
| Testing | XUnit, Moq, FluentAssertions |
| CI/CD | GitHub Actions → Azure App Service |

---

## 👤 Author

**Siddhant Jain**  
Software Engineer II @ Deloitte  
[LinkedIn](https://linkedin.com/in/siddhant-jain) · [Email](mailto:siddhantjain871@gmail.com)

---

## 📄 License

MIT — feel free to use this as a reference or starting point.
