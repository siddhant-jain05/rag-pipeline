using Microsoft.Extensions.Logging;
using RagPipeline.Application.DTOs;
using RagPipeline.Application.Interfaces;

namespace RagPipeline.Application.Services;

/// <summary>
/// Orchestrates the full RAG loop: Embed → Retrieve → Augment → Generate.
///
/// Design decisions:
/// - All external dependencies are injected as interfaces (testable, swappable)
/// - Prompt construction is isolated in BuildPrompt() for easy iteration
/// - Streaming and non-streaming paths share the same retrieval logic
/// </summary>
public sealed class RagService : IRagService
{
    private readonly IEmbeddingModel _embeddingModel;
    private readonly IVectorStore _vectorStore;
    private readonly ILanguageModel _languageModel;
    private readonly ILogger<RagService> _logger;

    private const int DefaultTopK = 5;
    private const int MaxContextTokens = 3000; // Rough guard against oversized prompts

    public RagService(
        IEmbeddingModel embeddingModel,
        IVectorStore vectorStore,
        ILanguageModel languageModel,
        ILogger<RagService> logger)
    {
        _embeddingModel = embeddingModel ?? throw new ArgumentNullException(nameof(embeddingModel));
        _vectorStore = vectorStore ?? throw new ArgumentNullException(nameof(vectorStore));
        _languageModel = languageModel ?? throw new ArgumentNullException(nameof(languageModel));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<QueryResponse> QueryAsync(QueryRequest request, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        _logger.LogInformation("RAG query started. Question length: {Length}", request.Question.Length);

        var (chunks, prompt) = await RetrieveAndBuildPromptAsync(request, ct);

        var answer = await _languageModel.CompleteAsync(prompt, ct);

        _logger.LogInformation("RAG query completed. Retrieved {ChunkCount} chunks.", chunks.Count);

        return new QueryResponse
        {
            Answer = answer,
            SourceChunks = chunks.Select(c => new SourceReference
            {
                ChunkId = c.Chunk.Id,
                DocumentId = c.Chunk.DocumentId,
                Content = c.Chunk.Content,
                RelevanceScore = c.Score,
                PageNumber = c.Chunk.PageNumber
            }).ToList()
        };
    }

    public async IAsyncEnumerable<string> QueryStreamAsync(
        QueryRequest request,
        [System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        var (_, prompt) = await RetrieveAndBuildPromptAsync(request, ct);

        await foreach (var token in _languageModel.StreamAsync(prompt, ct))
        {
            yield return token;
        }
    }

    // ── Private helpers ──────────────────────────────────────────────────────

    private async Task<(IReadOnlyList<ScoredChunk> Chunks, string Prompt)> RetrieveAndBuildPromptAsync(
        QueryRequest request, CancellationToken ct)
    {
        // Step 1: Embed the question
        var embedding = await _embeddingModel.EmbedAsync(request.Question, ct);

        // Step 2: Retrieve semantically similar chunks
        var chunks = await _vectorStore.SearchAsync(embedding, request.TopK ?? DefaultTopK, ct);

        // Step 3: Build the augmented prompt
        var prompt = BuildPrompt(request.Question, chunks);

        return (chunks, prompt);
    }

    /// <summary>
    /// Prompt engineering: system instruction + retrieved context + user question.
    ///
    /// Key choices:
    /// - Explicit grounding instruction reduces hallucination
    /// - "I don't know" fallback prevents confident wrong answers
    /// - Context is ordered by relevance score (highest first)
    /// </summary>
    private static string BuildPrompt(string question, IReadOnlyList<ScoredChunk> chunks)
    {
        var contextBuilder = new System.Text.StringBuilder();
        var tokenEstimate = 0;

        foreach (var scored in chunks.OrderByDescending(c => c.Score))
        {
            var chunkTokens = scored.Chunk.Content.Length / 4; // ~4 chars per token
            if (tokenEstimate + chunkTokens > MaxContextTokens) break;

            contextBuilder.AppendLine($"[Source: {scored.Chunk.DocumentId}, Page {scored.Chunk.PageNumber}]");
            contextBuilder.AppendLine(scored.Chunk.Content);
            contextBuilder.AppendLine();
            tokenEstimate += chunkTokens;
        }

        return $"""
            You are a precise document analysis assistant. Answer the user's question using ONLY
            the provided context. If the context does not contain enough information to answer,
            respond with "I don't have enough information in the provided documents to answer this."
            Do not fabricate information. Cite the source document when relevant.

            CONTEXT:
            {contextBuilder}

            QUESTION: {question}

            ANSWER:
            """;
    }
}
