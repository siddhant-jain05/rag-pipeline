namespace RagPipeline.Application.DTOs;

public sealed class QueryRequest
{
    public required string Question { get; init; }
    public int? TopK { get; init; } = 5;
}

public sealed class QueryResponse
{
    public required string Answer { get; init; }
    public List<SourceReference> SourceChunks { get; init; } = [];
}

public sealed class SourceReference
{
    public required string ChunkId { get; init; }
    public required string DocumentId { get; init; }
    public required string Content { get; init; }
    public float RelevanceScore { get; init; }
    public int PageNumber { get; init; }
}

public sealed class DocumentChunk
{
    public required string Id { get; init; }
    public required string DocumentId { get; init; }
    public required string Content { get; init; }
    public int PageNumber { get; init; }
    public float[]? Embedding { get; set; }
}

public sealed class ScoredChunk
{
    public required DocumentChunk Chunk { get; init; }
    public float Score { get; init; }
}
