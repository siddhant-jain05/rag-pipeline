namespace RagPipeline.Application.Interfaces;

/// <summary>
/// Core RAG orchestration contract.
/// Intentionally infrastructure-agnostic — no Azure SDK types leak into this layer.
/// </summary>
public interface IRagService
{
    /// <summary>
    /// Answers a natural language question by retrieving relevant document chunks
    /// and generating a grounded response via an LLM.
    /// </summary>
    Task<QueryResponse> QueryAsync(QueryRequest request, CancellationToken ct = default);

    /// <summary>
    /// Streams the answer token-by-token for low-latency UX.
    /// </summary>
    IAsyncEnumerable<string> QueryStreamAsync(QueryRequest request, CancellationToken ct = default);
}
