namespace RagPipeline.Application.Interfaces;

/// <summary>
/// Port for vector similarity search.
/// Concrete adapters: AzureSearchVectorStore, PineconeVectorStore, etc.
/// The application layer never knows which one is wired up.
/// </summary>
public interface IVectorStore
{
    Task UpsertAsync(IEnumerable<DocumentChunk> chunks, CancellationToken ct = default);
    Task<IReadOnlyList<ScoredChunk>> SearchAsync(float[] queryEmbedding, int topK = 5, CancellationToken ct = default);
    Task DeleteByDocumentIdAsync(string documentId, CancellationToken ct = default);
}
