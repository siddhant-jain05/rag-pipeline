namespace RagPipeline.Application.Interfaces;

/// <summary>
/// Port for text generation (GPT-4o, Claude, etc.).
/// </summary>
public interface ILanguageModel
{
    Task<string> CompleteAsync(string prompt, CancellationToken ct = default);
    IAsyncEnumerable<string> StreamAsync(string prompt, CancellationToken ct = default);
}

/// <summary>
/// Port for generating vector embeddings.
/// </summary>
public interface IEmbeddingModel
{
    Task<float[]> EmbedAsync(string text, CancellationToken ct = default);
}
