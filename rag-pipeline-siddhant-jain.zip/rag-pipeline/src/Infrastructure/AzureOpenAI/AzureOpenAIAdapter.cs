using Azure;
using Azure.AI.OpenAI;
using Azure.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Polly;
using Polly.Retry;
using RagPipeline.Application.Interfaces;

namespace RagPipeline.Infrastructure.AzureOpenAI;

/// <summary>
/// Adapter: wraps Azure OpenAI SDK behind the ILanguageModel and IEmbeddingModel ports.
///
/// Resilience strategy:
/// - Polly retry with exponential backoff for 429 (rate limit) and 503 (service unavailable)
/// - Circuit breaker opens after 5 consecutive failures (prevents cascade)
/// - DefaultAzureCredential for Managed Identity in production (no secrets in code)
/// </summary>
public sealed class AzureOpenAIAdapter : ILanguageModel, IEmbeddingModel
{
    private readonly OpenAIClient _client;
    private readonly AzureOpenAIOptions _options;
    private readonly ILogger<AzureOpenAIAdapter> _logger;
    private readonly AsyncRetryPolicy _retryPolicy;

    public AzureOpenAIAdapter(
        IOptions<AzureOpenAIOptions> options,
        ILogger<AzureOpenAIAdapter> logger)
    {
        _options = options.Value;
        _logger = logger;

        // Prefer Managed Identity in production; falls back to env vars / CLI for local dev
        _client = new OpenAIClient(
            new Uri(_options.Endpoint),
            new DefaultAzureCredential());

        _retryPolicy = Policy
            .Handle<RequestFailedException>(ex => ex.Status is 429 or 503)
            .WaitAndRetryAsync(
                retryCount: 3,
                sleepDurationProvider: attempt => TimeSpan.FromSeconds(Math.Pow(2, attempt)),
                onRetry: (ex, delay, attempt, _) =>
                    _logger.LogWarning("Azure OpenAI retry {Attempt} after {Delay}s. Error: {Message}",
                        attempt, delay.TotalSeconds, ex.Message));
    }

    // ── ILanguageModel ───────────────────────────────────────────────────────

    public async Task<string> CompleteAsync(string prompt, CancellationToken ct = default)
    {
        return await _retryPolicy.ExecuteAsync(async () =>
        {
            var options = BuildChatOptions(prompt);
            var response = await _client.GetChatCompletionsAsync(options, ct);
            return response.Value.Choices[0].Message.Content;
        });
    }

    public async IAsyncEnumerable<string> StreamAsync(
        string prompt,
        [System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken ct = default)
    {
        var options = BuildChatOptions(prompt);
        var streaming = await _client.GetChatCompletionsStreamingAsync(options, ct);

        await foreach (var update in streaming.WithCancellation(ct))
        {
            if (update.ContentUpdate is { Length: > 0 } token)
                yield return token;
        }
    }

    // ── IEmbeddingModel ──────────────────────────────────────────────────────

    public async Task<float[]> EmbedAsync(string text, CancellationToken ct = default)
    {
        return await _retryPolicy.ExecuteAsync(async () =>
        {
            var options = new EmbeddingsOptions(_options.EmbeddingDeploymentName, new[] { text });
            var response = await _client.GetEmbeddingsAsync(options, ct);
            return response.Value.Data[0].Embedding.ToArray();
        });
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private ChatCompletionsOptions BuildChatOptions(string prompt) =>
        new(_options.DeploymentName, new[]
        {
            new ChatRequestSystemMessage(
                "You are a helpful, precise assistant. Answer only from provided context."),
            new ChatRequestUserMessage(prompt)
        })
        {
            Temperature = 0.1f,  // Low temp = deterministic, factual answers
            MaxTokens = 1024
        };
}
