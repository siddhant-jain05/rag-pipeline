using Azure;
using Azure.Identity;
using Azure.Search.Documents;
using Azure.Search.Documents.Indexes;
using Azure.Search.Documents.Models;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RagPipeline.Application.DTOs;
using RagPipeline.Application.Interfaces;

namespace RagPipeline.Infrastructure.AzureSearch;

/// <summary>
/// Adapter: Azure AI Search as a vector store.
///
/// Uses hybrid search: keyword (BM25) + vector similarity.
/// Hybrid consistently outperforms pure vector search on factual Q&A tasks.
/// </summary>
public sealed class AzureSearchVectorStore : IVectorStore
{
    private readonly SearchClient _searchClient;
    private readonly AzureSearchOptions _options;
    private readonly ILogger<AzureSearchVectorStore> _logger;

    public AzureSearchVectorStore(
        IOptions<AzureSearchOptions> options,
        ILogger<AzureSearchVectorStore> logger)
    {
        _options = options.Value;
        _logger = logger;

        _searchClient = new SearchClient(
            new Uri(_options.Endpoint),
            _options.IndexName,
            new DefaultAzureCredential());
    }

    public async Task UpsertAsync(IEnumerable<DocumentChunk> chunks, CancellationToken ct = default)
    {
        var documents = chunks.Select(c => new SearchDocument
        {
            ["id"] = c.Id,
            ["documentId"] = c.DocumentId,
            ["content"] = c.Content,
            ["pageNumber"] = c.PageNumber,
            ["contentVector"] = c.Embedding,
            ["createdAt"] = DateTimeOffset.UtcNow
        });

        var batch = IndexDocumentsBatch.Upload(documents);
        var result = await _searchClient.IndexDocumentsAsync(batch, cancellationToken: ct);

        _logger.LogInformation("Upserted {Count} chunks to Azure AI Search.", result.Value.Results.Count);
    }

    public async Task<IReadOnlyList<ScoredChunk>> SearchAsync(
        float[] queryEmbedding, int topK = 5, CancellationToken ct = default)
    {
        // Hybrid search: semantic reranking + vector similarity
        var searchOptions = new SearchOptions
        {
            Size = topK,
            Select = { "id", "documentId", "content", "pageNumber" },
            VectorSearch = new VectorSearchOptions
            {
                Queries =
                {
                    new VectorizedQuery(queryEmbedding)
                    {
                        KNearestNeighborsCount = topK * 2, // Retrieve more, rerank to topK
                        Fields = { "contentVector" }
                    }
                }
            },
            QueryType = SearchQueryType.Semantic,
            SemanticSearch = new SemanticSearchOptions
            {
                SemanticConfigurationName = _options.SemanticConfigName
            }
        };

        var results = await _searchClient.SearchAsync<SearchDocument>(
            searchText: null, // Vector-only query; set to a string for hybrid
            searchOptions,
            ct);

        var scored = new List<ScoredChunk>();

        await foreach (var result in results.Value.GetResultsAsync().WithCancellation(ct))
        {
            scored.Add(new ScoredChunk
            {
                Chunk = new DocumentChunk
                {
                    Id = result.Document["id"].ToString()!,
                    DocumentId = result.Document["documentId"].ToString()!,
                    Content = result.Document["content"].ToString()!,
                    PageNumber = Convert.ToInt32(result.Document["pageNumber"])
                },
                Score = result.SemanticSearch?.RerankerScore ?? result.Score ?? 0
            });
        }

        return scored.OrderByDescending(s => s.Score).ToList();
    }

    public async Task DeleteByDocumentIdAsync(string documentId, CancellationToken ct = default)
    {
        // Find all chunks for this document, then delete in batch
        var options = new SearchOptions { Filter = $"documentId eq '{documentId}'", Select = { "id" } };
        var results = await _searchClient.SearchAsync<SearchDocument>("*", options, ct);

        var ids = new List<string>();
        await foreach (var r in results.Value.GetResultsAsync().WithCancellation(ct))
            ids.Add(r.Document["id"].ToString()!);

        if (ids.Count == 0) return;

        var batch = IndexDocumentsBatch.Delete("id", ids);
        await _searchClient.IndexDocumentsAsync(batch, cancellationToken: ct);

        _logger.LogInformation("Deleted {Count} chunks for document {DocumentId}.", ids.Count, documentId);
    }
}
