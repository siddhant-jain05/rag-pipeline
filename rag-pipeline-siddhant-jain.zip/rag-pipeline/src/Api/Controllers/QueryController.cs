using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using RagPipeline.Application.DTOs;
using RagPipeline.Application.Interfaces;

namespace RagPipeline.Api.Controllers;

/// <summary>
/// Exposes RAG query endpoints.
/// Two modes: standard (full response) and streaming (SSE token-by-token).
/// </summary>
[ApiController]
[Route("api/[controller]")]
[EnableRateLimiting("fixed")]
public sealed class QueryController : ControllerBase
{
    private readonly IRagService _ragService;
    private readonly ILogger<QueryController> _logger;

    public QueryController(IRagService ragService, ILogger<QueryController> logger)
    {
        _ragService = ragService;
        _logger = logger;
    }

    /// <summary>
    /// Ask a question. Returns the full answer with source citations.
    /// </summary>
    /// <response code="200">Answer with source chunk references</response>
    /// <response code="400">Invalid request</response>
    [HttpPost]
    [ProducesResponseType(typeof(QueryResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> QueryAsync(
        [FromBody] QueryRequest request,
        CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(request.Question))
            return BadRequest("Question cannot be empty.");

        _logger.LogInformation("Query received: {QuestionPreview}",
            request.Question[..Math.Min(50, request.Question.Length)]);

        var response = await _ragService.QueryAsync(request, ct);
        return Ok(response);
    }

    /// <summary>
    /// Ask a question with streaming response (Server-Sent Events).
    /// Connect via EventSource in the browser or curl --no-buffer.
    /// </summary>
    [HttpPost("stream")]
    [Produces("text/event-stream")]
    public async Task QueryStreamAsync(
        [FromBody] QueryRequest request,
        CancellationToken ct)
    {
        Response.Headers.Append("Content-Type", "text/event-stream");
        Response.Headers.Append("Cache-Control", "no-cache");
        Response.Headers.Append("X-Accel-Buffering", "no"); // Disable nginx buffering

        await foreach (var token in _ragService.QueryStreamAsync(request, ct))
        {
            await Response.WriteAsync($"data: {token}\n\n", ct);
            await Response.Body.FlushAsync(ct);
        }

        // Signal stream completion
        await Response.WriteAsync("data: [DONE]\n\n", ct);
    }
}
