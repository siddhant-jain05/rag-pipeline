using FluentAssertions;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;
using RagPipeline.Application.DTOs;
using RagPipeline.Application.Interfaces;
using RagPipeline.Application.Services;
using Xunit;

namespace RagPipeline.Application.Tests;

/// <summary>
/// Unit tests for RagService — the core RAG orchestration logic.
/// All external dependencies are mocked. Zero Azure SDK dependency here.
/// </summary>
public sealed class RagServiceTests
{
    private readonly Mock<IEmbeddingModel> _mockEmbedding = new();
    private readonly Mock<IVectorStore> _mockVectorStore = new();
    private readonly Mock<ILanguageModel> _mockLlm = new();
    private readonly RagService _sut;

    public RagServiceTests()
    {
        _sut = new RagService(
            _mockEmbedding.Object,
            _mockVectorStore.Object,
            _mockLlm.Object,
            NullLogger<RagService>.Instance);
    }

    [Fact]
    public async Task QueryAsync_WhenChunksFound_ShouldReturnAnswerWithSources()
    {
        // Arrange
        var fakeEmbedding = new float[] { 0.1f, 0.2f, 0.3f };
        var fakeChunks = new List<ScoredChunk>
        {
            new() { Chunk = Chunk("chunk-1", "doc-1", "Scope 3 covers indirect emissions."), Score = 0.95f },
            new() { Chunk = Chunk("chunk-2", "doc-1", "Suppliers are part of scope 3."), Score = 0.87f }
        };

        _mockEmbedding
            .Setup(e => e.EmbedAsync(It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(fakeEmbedding);

        _mockVectorStore
            .Setup(v => v.SearchAsync(fakeEmbedding, It.IsAny<int>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(fakeChunks);

        _mockLlm
            .Setup(l => l.CompleteAsync(It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync("Scope 3 includes indirect emissions from suppliers.");

        // Act
        var result = await _sut.QueryAsync(new QueryRequest { Question = "What is scope 3?" });

        // Assert
        result.Answer.Should().Be("Scope 3 includes indirect emissions from suppliers.");
        result.SourceChunks.Should().HaveCount(2);
        result.SourceChunks[0].DocumentId.Should().Be("doc-1");
        result.SourceChunks[0].RelevanceScore.Should().BeGreaterThan(0.8f);
    }

    [Fact]
    public async Task QueryAsync_ShouldEmbedQuestionBeforeSearching()
    {
        // Arrange — verify the RAG loop calls embed first, then search
        SetupHappyPath();

        // Act
        await _sut.QueryAsync(new QueryRequest { Question = "Test question" });

        // Assert — order matters: embed → search → generate
        _mockEmbedding.Verify(e => e.EmbedAsync("Test question", It.IsAny<CancellationToken>()), Times.Once);
        _mockVectorStore.Verify(v => v.SearchAsync(It.IsAny<float[]>(), It.IsAny<int>(), It.IsAny<CancellationToken>()), Times.Once);
        _mockLlm.Verify(l => l.CompleteAsync(It.IsAny<string>(), It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task QueryAsync_WhenNoChunksFound_ShouldStillReturnAnswer()
    {
        // Arrange — vector store returns empty (edge case: document not indexed yet)
        _mockEmbedding.Setup(e => e.EmbedAsync(It.IsAny<string>(), default)).ReturnsAsync(Array.Empty<float>());
        _mockVectorStore.Setup(v => v.SearchAsync(It.IsAny<float[]>(), It.IsAny<int>(), default))
            .ReturnsAsync(new List<ScoredChunk>());
        _mockLlm.Setup(l => l.CompleteAsync(It.IsAny<string>(), default))
            .ReturnsAsync("I don't have enough information in the provided documents to answer this.");

        // Act
        var result = await _sut.QueryAsync(new QueryRequest { Question = "Unknown topic" });

        // Assert — graceful degradation, not an exception
        result.Answer.Should().Contain("I don't have enough information");
        result.SourceChunks.Should().BeEmpty();
    }

    [Fact]
    public async Task QueryAsync_NullRequest_ShouldThrowArgumentNullException()
    {
        // Act & Assert
        await _sut.Invoking(s => s.QueryAsync(null!))
            .Should().ThrowAsync<ArgumentNullException>();
    }

    [Theory]
    [InlineData(3)]
    [InlineData(5)]
    [InlineData(10)]
    public async Task QueryAsync_ShouldRespectTopKParameter(int topK)
    {
        // Arrange
        SetupHappyPath();

        // Act
        await _sut.QueryAsync(new QueryRequest { Question = "Question", TopK = topK });

        // Assert — topK is passed through to the vector store
        _mockVectorStore.Verify(
            v => v.SearchAsync(It.IsAny<float[]>(), topK, It.IsAny<CancellationToken>()),
            Times.Once);
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private void SetupHappyPath()
    {
        _mockEmbedding.Setup(e => e.EmbedAsync(It.IsAny<string>(), default))
            .ReturnsAsync(new float[] { 0.1f });
        _mockVectorStore.Setup(v => v.SearchAsync(It.IsAny<float[]>(), It.IsAny<int>(), default))
            .ReturnsAsync(new List<ScoredChunk> { new() { Chunk = Chunk("c1", "d1", "content"), Score = 0.9f } });
        _mockLlm.Setup(l => l.CompleteAsync(It.IsAny<string>(), default))
            .ReturnsAsync("Answer");
    }

    private static DocumentChunk Chunk(string id, string docId, string content) =>
        new() { Id = id, DocumentId = docId, Content = content, PageNumber = 1 };
}
